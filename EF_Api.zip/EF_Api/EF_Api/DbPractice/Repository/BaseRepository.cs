﻿using EF_Api.DB.models;
using EF_Api.DbPractice.InterFace;
using System.Collections.Generic;
using System.Linq;

namespace EF_Api.DbPractice.Repository
{
    public class BaseRepository<T> : IBaseRepository<T> where T : class
    {
        private bookStoresDBContext context;
       public BaseRepository(bookStoresDBContext bookStoreDBContext)
        {
            context=bookStoreDBContext;
        }
        public T Add(T entity)
        {
            this.context.Set<T>().Add(entity);
            return entity; 
        }

        public T FindById(int id)
        {
           return context.Find<T>(id);
        }

        public IEnumerable<T> GetAll()
        {
            return context.Set<T>().ToList();
        }

        public void Remove(T entity)
        {
            context.Set<T>().Remove(entity);
        }

        public T Update(T entity)
        {
            throw new System.NotImplementedException();
        }
    }
}
