﻿using System.Collections.Generic;

namespace EF_Api.DbPractice.InterFace
{
    public interface IBaseRepository <T> where T:class
    {
        T Add(T entity);
        T Update (T entity);
        T FindById(int id);
        IEnumerable<T> GetAll();
        void Remove(T entity);


    }
}
