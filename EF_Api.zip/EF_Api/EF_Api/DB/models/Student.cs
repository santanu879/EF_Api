﻿namespace EF_Api.DB.models
{
    public class Student
    {
        public int Id { get; set; }
    }
}
