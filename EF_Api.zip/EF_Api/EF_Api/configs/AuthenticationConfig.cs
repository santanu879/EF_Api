﻿namespace EF_Api.configs
{
    public class AuthenticationConfig
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Key { get; set; }
    }
}
