﻿namespace EF_Api.Schemas
{
    public static class AuthenticationSchemaNames
    {
        public const string ApiKeyAuthentication = nameof(ApiKeyAuthentication);
        public const string BasicAuthentication = nameof(BasicAuthentication);

        public const string MixSchemaNames = nameof(ApiKeyAuthentication) + "," + nameof(BasicAuthentication);
    }

    public static class HeaderKeyNames
    {
        public const string ApiKeyAuthenticationKey = "X-API-KEY";
    }
}
