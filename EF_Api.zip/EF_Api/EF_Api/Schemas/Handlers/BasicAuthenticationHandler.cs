﻿using EF_Api.configs;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;
using System;
using System.Linq;
using System.Net;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Text;
using System.Text.Encodings.Web;
using System.Threading.Tasks;

namespace EF_Api.Schemas.Handlers
{
    public class BasicAuthenticationHandler : AuthenticationHandler<AuthenticationSchemeOptions>
    {
        readonly AuthenticationConfig _authenticationConfig;
        public BasicAuthenticationHandler
            (IOptionsMonitor<AuthenticationSchemeOptions> options,
            ILoggerFactory logger, UrlEncoder encoder, ISystemClock clock,
            IOptions<AuthenticationConfig> authenticationConfig)
            : base(options, logger, encoder, clock)
        {
            _authenticationConfig = authenticationConfig.Value;
        }

        protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
        {
            string externalApiUser = string.Empty;
            if (Request.HttpContext.User.Identity.IsAuthenticated)
                return await Task.FromResult(AuthenticateResult.NoResult());

            if (!string.IsNullOrWhiteSpace(Request.HttpContext.User?.Identity?.Name))
                return await Task.FromResult(AuthenticateResult.NoResult()); //Already authenticated  


            if (!Request.Headers.ContainsKey("Authorization"))
                return await Task.FromResult(AuthenticateResult.Fail("Missing Authorization Header"));

            string username = null;
            try
            {
                var authHeader = AuthenticationHeaderValue.Parse(Request.Headers["Authorization"]);
                var credentialBytes = Convert.FromBase64String(authHeader.Parameter);
                var credentials = Encoding.UTF8.GetString(credentialBytes).Split(new[] { ':' }, 2);
                username = credentials.FirstOrDefault();
                var password = credentials.LastOrDefault();
                externalApiUser = string.Concat("ExternalApi-", username);
                if (!username.Equals(_authenticationConfig.Username) || !password.Equals(_authenticationConfig.Password))
                    throw new ArgumentException("Invalid username or password");
            }
            catch
            {
                return await Task.FromResult(AuthenticateResult.Fail("Invalid Authorization Header"));
            }

            var claims = new Claim[]
                {
                    new Claim(ClaimTypes.NameIdentifier, externalApiUser),
                    new Claim(ClaimTypes.Role, "Read"),
                    new Claim(ClaimTypes.Role, "Write"),
                    new Claim(ClaimTypes.Role, "View"),
                    new Claim(ClaimTypes.Role, "Publish")
                };

            var identity = new ClaimsIdentity(claims, Scheme.Name);
            var principal = new ClaimsPrincipal(identity);
            var ticket = new AuthenticationTicket(principal, Scheme.Name);

            return AuthenticateResult.Success(ticket);

        }
    }
}