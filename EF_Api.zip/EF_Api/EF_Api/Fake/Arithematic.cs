﻿namespace EF_Api.Fake
{
    public class Arithematic
    {
        public virtual bool CheckDigitOnly()
        {
            return false;
        }
    }
}
