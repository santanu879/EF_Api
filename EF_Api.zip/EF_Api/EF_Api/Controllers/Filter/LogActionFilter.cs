﻿using Microsoft.AspNetCore.Mvc.Filters;

namespace EF_Api.Controllers.Filter
{
    public class LogActionFilter: ActionFilterAttribute
    {
    }
}
