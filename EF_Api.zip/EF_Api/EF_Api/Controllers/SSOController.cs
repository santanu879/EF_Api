﻿using EF_Api.configs;
using EF_Api.DB.models;
using EF_Api.Schemas.Handlers;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using System.Threading.Tasks;

namespace EF_Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SSOController : ControllerBase
    {
        private ITokenService _tokenService;
        readonly JWTConfig _configuration;
        public SSOController(ITokenService tokenService, IOptions<JWTConfig> Jwtconfig)
        {
            _tokenService = tokenService;
            _configuration= Jwtconfig.Value; 
        }
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult> Login(User user)
        {
            string Token = string.Empty;
            await Task.Run(() =>
            {
                Token= _tokenService.BuildToken(_configuration.Key, _configuration.Issuer, _configuration.Audience, user);
            });
            return Ok(Token);
          
        }
    }
}
