﻿using EF_Api.DB.Interface;
using EF_Api.DB.models;
using EF_Api.External_Api.Interface;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.JsonPatch;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Net;
using System.Threading.Tasks;

namespace EF_Api.Controllers
{
    //[Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class PublisherController : ControllerBase
    {
        private readonly ILogger<PublisherController> _logger;
        private readonly IUnitOfWork _unitOfWork;
        private readonly IHolidaysApiService _holidayApiService;
        public PublisherController(ILogger<PublisherController> logger,
             IUnitOfWork unitOfWork, IHolidaysApiService holidaysApiService)
        {
            _logger = logger;
            _unitOfWork = unitOfWork;
            _holidayApiService = holidaysApiService;
        }
        [HttpGet]
        public async Task<IActionResult> Get()
        {
            try
            {
                var result = _unitOfWork.Publisher.GetAll();
                return StatusCode(200, result);
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Post([FromBody] Publisher publisher)
        {
            try
            {
                publisher.Book.Add(new Book { Title = "Book1",Price=80});
                _unitOfWork.Publisher.Add(publisher);
                
                var result=_unitOfWork.Complete();
                return StatusCode(200, result);
            }
            catch (Exception ex)
            {
                return StatusCode(400, ex.Message);
            }
        }

        [HttpPatch]
        public async Task<IActionResult> Patch([FromBody] JsonPatchDocument<Publisher> publisher)
        {

            var data=_unitOfWork.Publisher.GetById(51);            
            if (data==null)
            {
                return NotFound();
            }
            publisher.ApplyTo(data);
            _unitOfWork.Publisher.Update(data);
            _unitOfWork.Complete();
            return Ok(publisher);
        }
    }
}
